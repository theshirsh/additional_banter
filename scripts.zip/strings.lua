---------------------------------------------------------------------
-- Invisible Inc. MOD.
--

local DLC_STRINGS =
{	           
	
	OPTIONS =
	{
		BANTER = "Additional banter.",
		BANTER_TIP = "<c:FF8411>Adds mission start banters for multiple basegame, DLC and mod agents</c>",  
				
	},	

}

return DLC_STRINGS