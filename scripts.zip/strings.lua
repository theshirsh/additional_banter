---------------------------------------------------------------------
-- Invisible Inc. MOD.
--

local DLC_STRINGS =
{	           
	
	OPTIONS =
	{
		BANTER = "Additional banter.",
		BANTER_TIP = "<c:FF8411>Added several dialogues for:</c>\nCentral & M0nster\nDraco(DLC)\nRush(DLC)\nOlivia & Derek(DLC)",  
				
	},	

}

return DLC_STRINGS