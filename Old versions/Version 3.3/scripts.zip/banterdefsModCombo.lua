---------------------------------------------------------------------
-- Invisible Inc. Mod. more banter for agents added by mods

--[[ 
	Content:		
		Pedler, Mist + vanilla agents		by Caischcer: 27
		N-Umi, Ghuff and Mist + vanilla		by Linenpixel: 84
		Sombra								by WMGreywind: 12
		Various edits						by Hekateras: 2

]]

local agentdefs = include("sim/unitdefs/agentdefs")

local DECKER = 1
local SHALEM = 2
local XU =  3
local BANKS = 4
local INTERNATIONALE =  5
local NIKA = 6
local SHARP = 7
local PRISM = 8
local CENTRAL = 108
local MONSTER = 100	

local OLIVIA = 1000
local DEREK = 1001
local RUSH = 1002
local DRACO = 1003
	
local PEDLER = "mod_01_pedler"
local MIST = "mod_02_mist"
local GHUFF = "mod_03_ghuff"
local N_UMI = "mod_04_n_umi"

local DOSAN = "dosan_01"	--unused
local CONWAY = "gunpoint_conway"
local SOMBRA = "SOMBRA_001"	 -- from Talon Recruitment mod
local WIDOWMAKER = "WIDOWMAKER_001"	--unused, from Talon Recruitment mod

local CARMEN = "carmen_sandiego_o" -- from Carmen Sandiego mod

local NATE = "lever_01_chrysler" -- from Age of Lever mod
local ELIAS = "lever_02_elias"
local SOFTSON = "lever_03_softson"
local PIKER = "lever_04_piker"
local SARAH = "lever_05_sarah"
local SOPHIE = "lever_06_beveraux"

local banter =
{
-- Pedler:
	-- Pedler + Decker
--by Caischcer--
{
		agents = {PEDLER,DECKER},
		dialogue = {
			{PEDLER,"Just like the good old days."},
			{DECKER,"Are you calling me old, tin can?"},
			{PEDLER,"I see you have not lost your charm."},
			{DECKER,"And I see you haven't lost your rust!"},
		},
	},
--by Caischcer--
	--Pedler + Tony
 {
		agents = {PEDLER, XU},
		dialogue = {
			{XU, "Can you tell me what the log of 2074 is?"},
			{PEDLER,"Rounding up to six decimal places, 3.316808."},
			{XU, "What about one divided by zero?"},
			{PEDLER,"That is not funny."},
		},					
	},
--by Caischcer--
-- Edited this one to be less OOC in regards to both Xu and what the word "brute" means -Hek
	
 {
		agents = {PEDLER, XU},
		dialogue = {
			{PEDLER,"I once met your friend Alex at a conference, you know."},
			{XU, "That megalomanic smart-ass? Oh, I wouldn't quite say he's my friend."},
			{PEDLER,"Yeah, he said the same about you."},
		},				
	},
--by Caischcer--	
			
	--Pedler + Nika	
 {
		agents = {PEDLER, NIKA},
		dialogue = {
			{PEDLER,"Do you prefer to hit them a lot or to hit them strong?"},
			{NIKA, "I prefer to hit them dead."},
			{PEDLER,"But remember, we must stay stealthy."},
			{NIKA, "It's more important to stay alive."},
		},
	},

	--Pedler + Sharp
--by Caischcer--
{
		agents = {PEDLER, SHARP},
		dialogue = {
			{SHARP, "What does it feel like to be a robot?"},
			{PEDLER, "I do miss the days when I was human."},
			{SHARP, "And why is that?"},
			{PEDLER, "Well, I miss tea, but electrons don't taste that bad either"},
		},
	},
		
	-- PEDLER speaks about beaches with everyone (meta easter egg or somthn)
	-- "We will fight them on the beaches!", as that quote made more questions that answers in community 
--by Caischcer--
 {
		agents = {PEDLER,DECKER},
		dialogue = {
			{PEDLER,"We will fight them on the beaches!"},
			{DECKER,"With blood, oil, gears, and sweat! This will be our finest hour!"},
			{PEDLER,"Just like the good old days."},
			{DECKER,"I'd drink to that." },
		},
	},
--by Caischcer--
{
		agents = {PEDLER,INTERNATIONALE},
		dialogue = {
			{PEDLER,"We will fight them on the beaches!"},
			{INTERNATIONALE,"I'd love to! But they have no open facilities on a sea-shore." },
			{PEDLER,"It was just a quote." },
			{INTERNATIONALE,"Too late, I feel homesick now." },
		},		
	},
--by Caischcer--
{
		agents = {PEDLER,SHALEM},
		dialogue = {
			{PEDLER,"We will fight them on the beaches!"},
			{SHALEM,"Dream on. As if any self respecting real estate owner would let a tin-head like you on their resort territory." },
			{PEDLER,"... \nNow that was unnecessarily rude." },			
		},		
	},
--by Caischcer--
{
		agents = {PEDLER,BANKS},
		dialogue = {
			{PEDLER,"We will fight them on the beaches!"},
			{BANKS,"Let me guess, your swimsuit has blue and white stripes?"},
			{PEDLER,"What? No! It was a quote." },
			{BANKS,"No? Still, I expect it to be a rather jolly swimsuit." },
		},	
	},
--by Caischcer--
 {
		agents = {PEDLER,XU},
		dialogue = {
			{PEDLER,"We will fight them on the beaches!"},
			{XU,"Where the girl from Ipanema goes for a walk?" },
			{PEDLER,"No, it was a quote." },
			{XU,"I see. Isn't saltwater unhealthy for you, by the way?"},
		},	
	},
--by Caischcer--
{
		agents = {PEDLER,NIKA},
		dialogue = {
			{PEDLER,"We will fight them on the beaches!"},
			{NIKA,"... \nExcuse me?" },
			{PEDLER,"It was an old quote." },
			{NIKA,"..." },
		},
	},
--by Caischcer--
{
		agents = {PEDLER,SHARP},
		dialogue = {
			{PEDLER,"We will fight them on the beaches!"},
			{SHARP,"Memory defragmentation gone awry?" },
			{PEDLER,"It was a quote." },
			{SHARP,"You remember it wrong, that's what I'm trying to say." },
		},	
	},
--by Caischcer--
{
		agents = {PEDLER,PRISM},
		dialogue = {
			{PEDLER,"We will fight them on the beaches!"},
			{PRISM,"Is that from an old holo-vid?" },
			{PEDLER,"It was a quote." },
			{PRISM,"I get it. Just can't remember seeing that one." },
		},
	},
	
-- with DLC agents
--by Caischcer--
{
		agents = {PEDLER,DRACO},
		dialogue = {
			{PEDLER,"We will fight them on the beaches!"},
			{DRACO,"Beaches are windy. That's a terrible place for a duel." },
			{PEDLER,"It was a quote." },
			{DRACO,"Obviously not from me." },
		},	
	},
--by Caischcer--
{
		agents = {PEDLER,RUSH},
		dialogue = {
			{PEDLER,"We will fight them on the beaches!"},
			{RUSH,"The sun is nice, but running around and getting sand in my shoes? No thanks." },
			{PEDLER,"It was a quote." },
			{RUSH,"Whatever you say, tin man." },
		},
	},
--by Caischcer--	
{
		agents = {PEDLER,OLIVIA},
		dialogue = {
			{PEDLER,"We will fight them on the beaches!"},
			{OLIVIA,"I don't recall that particular code. Perhaps you could enlighten me." },
			{PEDLER,"It was a quote." },
			{OLIVIA,"Avoid direct combat when possible. That's an order." },
		},			
	},
--by Caischcer--
{
		agents = {PEDLER,DEREK},
		dialogue = {
			{PEDLER,"We will fight them on the beaches!"},
			{DEREK,"Did I ever tell you not to use cheap tech? I have much better in stock." },
			{PEDLER,"It was a quote."},
			{DEREK,"I can supply you under the radar, you know." },
		},
	},
--by Caischcer--
-- doubles previous 2
{
		agents = {PEDLER,CENTRAL},
		dialogue = {
			{PEDLER,"We will fight them on the beaches!"},
			{CENTRAL,"I couldn't recall that code in detail. Can you enlighten me?" },
			{PEDLER,"It was a quote." },
			{CENTRAL,"Order is to avoid direct combat when possible. Repeat." },
		},			
	},
--by Caischcer--
{
		agents = {PEDLER,MONSTER},
		dialogue = {
			{PEDLER,"We will fight them on the beaches!"},
			{MONSTER,"Did I ever tell you not to use cheap lenses? I have much better in stock." },
			{PEDLER,"It was a quote."},
			{MONSTER,"I can supply you under the radar, you know." },
		},
	},
--by Caischcer--
{
		agents = {PEDLER,MIST},
		dialogue = {
			{PEDLER,"We will-"},
			{MIST,"...fight them on the beaches!" },
			{PEDLER,"How did you...?" },
			{MIST,"It was a quote."},
		},	
	},
	
-- Mist:
--by Caischcer--
	-- Mist + Internationale
{
		agents = {MIST, INTERNATIONALE},
		dialogue = {
			{INTERNATIONALE, "What do you think goes through these people's minds?"},
			{MIST, "Nothing pretty, from where I've been."},
			{INTERNATIONALE, "You've... been there?"},
			{MIST, "I would prefer to avoid discussing the details."},
		},		
	},	

	-- Mist + Decker
--by Caischcer--
{
		agents = {MIST, DECKER},
		dialogue = {				
			{MIST, "Would you stop thinking about whiskey for just one minute?!"},
			{DECKER, "How the hell-"},
			{MIST, "Just focus, okay?"},
			{DECKER, "Yeah, that's creepy..."},
		},
	},

	-- Mist + Pedler
--by Caischcer--
{
		agents = {MIST, PEDLER},
		dialogue = {
			{PEDLER, "Hey lady, let's play a game. If you guess what number I am thinking of, I will give you 50 credits."},
			{MIST, "I only read fleshed out minds, sorry."},
			{PEDLER, "One! I thought of one. I can only think of two numbers, actually."},
			{MIST, "Silly robot."},
		},		
	},

	-- Mist + Shalem
--by Caischcer--
{
		agents = {MIST, SHALEM},
		dialogue = {
			{SHALEM, "Don't worry miss, I will protect you."},
			{MIST, "Thanks, but I don't trust opportunists."},
			{SHALEM, "Excuse me?"},
			{MIST, "You think I'm that easy to trick?"},
		},		
	},

	-- Mist + M0nster
--by Caischcer--
{
		agents = {MIST, MONSTER},
		dialogue = {				
			{MIST, "Don't trust that guy."},
			{MONSTER, "Are you talking to me?"},
			{MIST, "Trust me, I've known corporate buffoons better than you."},
			{MONSTER, "Please don't go meddling in my business."},
		},	
	},


	-- Mist + Banks
--by Caischcer--		
{
		agents = {MIST, BANKS},
		dialogue = {
			{BANKS, "All this pressure is driving me insane."},
			{MIST, "No, you may actually be the most sane of the group."},
			{BANKS, "Huh? What did you say?"},
			{MIST, "Sorry, I was thinking out loud."},
		},		
	},

	-- Mist + Derek	
--by Caischcer--
{
		agents = {MIST, DEREK},
		dialogue = {				
			{MIST, "Don't trust that guy."},
			{DEREK, "You talking to me?"},
			{MIST, "Trust me, I've known corporate buffoons better than you."},
			{DEREK, "Please don't go meddling in my business."},
		},	
	}, 	
	
	
	-- mod + vanilla agent banter
	--by Linenpixel--
	
{
		agents = {XU, N_UMI},
		dialogue = {
			{N_UMI, "There's something I want to ask you later."},
			{XU, "Why not ask me now?"},
			{N_UMI, "It's technical."},
			{XU, "I always have time for technical."},
			{N_UMI, "Yes, but the integrity of the mission doesn't."},
		},
	},
--by Linenpixel--	
{
		agents = {XU, N_UMI},
		dialogue = {
			{XU, "You do good work with drones."},
			{N_UMI, "Thank you."},
			{XU, "If you ever want to collaborate..."},
			{N_UMI, "If you ever designed drones, you'd make them randomly explode because you thought it was funnier."},
			{XU, "Don't be ridiculous! My explosions are not random. They are precisely timed."},
		},
	},
--by Linenpixel--	
{
		agents = {XU, N_UMI},
		dialogue = {
			{N_UMI, "If you could go back to the corporate world, would you?"},
			{XU, "Probably not. Invisible gives me access to a much more interesting variety of tech. Not to mention greater academic freedom."},
			{N_UMI, "...I see."},
		},
	},
--by Linenpixel--	
{
		agents = {XU, MIST},
		dialogue = {
			{XU, "Your abilities are fascinating."},
			{MIST, "Don't think you're going to get to study them. I've had enough of being treated like an experiment."},
			{XU, "I'm sorry."},
			{MIST, "Interesting. You actually meant that."},
		},
	},
--by Linenpixel--	
{
		agents = {MIST, NIKA},
		dialogue = {
			{NIKA, "You are useful, even if I prefer a less subtle approach."},
			{MIST, "Wow. I guess I should be honored that you chose to spend so many words on me."},
			{NIKA, "Yes."},
		},
	},
--by Linenpixel--	
{
		agents = {MIST, BANKS},
		dialogue = {
			{BANKS, "You'd better not go poking around in my mind."},
			{MIST, "I won't."},
			{BANKS, "You wouldn't like what's in there, anyway."},
			{MIST, "It can't be too scary. You're not like some of the other agents."},
			{BANKS, "Maybe not, but it's really confusing. You might get lost."},
		},
	},
--by Linenpixel--	
{
		agents = {MIST, BANKS},
		dialogue = {
			{MIST, "I know what it's like to have the corps messing with your brain."},
			{BANKS, "Thanks, but all the ''messing with my brain'', I did of my own accord."},
			{MIST, "Oh..."},
			{BANKS, "It seemed like a good idea at the time, all right?"},
		},
	},
--by Linenpixel--	
{
		agents = {MIST, INTERNATIONALE},
		dialogue = {
			{INTERNATIONALE, "Your political education can't have been very good, growing up in a corp lab."},
			{MIST, "Probably not."},
			{INTERNATIONALE, "I have some pamphlets I could give you. And books."},
			{MIST, "The others warned me about this."},
			{INTERNATIONALE, "Why is everyone so afraid of change?"},
		},
	},
--by Linenpixel--
{
		agents = {MIST, DECKER},
		dialogue = {
			{MIST, "If you ever need some extra help disappearing, let me know."},
			{DECKER, "I don't need help from your freaky newfangled psionics or whatever they are."},
			{MIST, "Right. Only old-fashioned cloaking rigs for you."},
		},
	},
	
--by Linenpixel--
{
		agents = {GHUFF, DECKER},
		dialogue = {
			{GHUFF, "You know, I don't see what the big deal is about your look. The hat and so on."},
			{DECKER, "Really?"},
			{GHUFF, "I mean, I wouldn't be caught dead in it myself, but I appreciate that you commit to it."},
		},
	},
--by Linenpixel--		
{
		agents = {GHUFF, PRISM},
		dialogue = {
			{GHUFF, "I've used disguises too, in my day."},
			{PRISM, "Fake moustaches?"},
			{GHUFF, "What do you take me for?"},
			{PRISM, "Sometimes cheap stuff gets the job done. People see what they want to see."},
			{GHUFF, "Oh, right, I getcha."},
		},
	},
--by Linenpixel--		
{
		agents = {GHUFF, XU},
		dialogue = {
			{GHUFF, "You're no different than every other black market scientist I've met."},
			{XU, "Have you met many?"},
			{GHUFF, "Yes, and I've never let any of them get the drop on me."},
		},
	},
--by Linenpixel--		
{
		agents = {GHUFF, MONSTER},
		dialogue = {
			{MONSTER, "Let me know if you're in the market for some new toys."},
			{GHUFF, "''Toys.'' You think this is a game. Typical."},
		},
	},
--by Linenpixel--	
{
		agents = {GHUFF, BANKS},
		dialogue = {
			{GHUFF, "I heard a lot about you, back in the day."},
			{BANKS, "Yes... it seems like everyone I meet says that."},
			{GHUFF, "Do you not want to talk about it?"},
			{BANKS, "Talk about it, sure. Remembering all of it is another matter."},
		},
	},
--by Linenpixel--	
{
		agents = {GHUFF, SHALEM},
		dialogue = {
			{GHUFF, "Don't ask about my past and I won't ask about yours, okay?"},
			{SHALEM, "I couldn't agree more."},
		},
	},
--by Linenpixel--		
{
		agents = {N_UMI, SHARP},
		dialogue = {
			{SHARP, "I have more in common with your drones than with you."},
			{N_UMI, "I highly doubt that, but the last thing I want to do is go poking around your insides."},
		},
	},
--by Linenpixel--		
{
		agents = {N_UMI, PRISM},
		dialogue = {
			{PRISM, "So you've escaped the corps too."},
			{N_UMI, "Isn't that why we're all here, in a sense?"},
			{PRISM, "Yes, but some of us have seen more of their inner workings than others."},
			{N_UMI, "True."},
		},
	},
--by Linenpixel--		
{
		agents = {N_UMI, NIKA},
		dialogue = {
			{NIKA, "I wouldn't leave important work to drones. They're too prone to malfunctions."},
			{N_UMI, "Human bodies can malfunction too."},
			{NIKA, "Yes. I make that happen."},
		},
	},
--by Linenpixel--	
{
		agents = {N_UMI, SHALEM},
		dialogue = {
			{SHALEM, "Murder drones are the easy way out."},
			{N_UMI, "I don't make ''murder drones'', but how is that different from using human soldiers?"},
			{SHALEM, "It's not, but it's easier."},
		},
	},
		
--by Linenpixel--
--pedler nika
{
	agents = {NIKA, PEDLER},
	dialogue = {
		{PEDLER, "*I have no bones that you could break.*"},
		{NIKA, "There is a way to break everything."},
	},},
	
--by Linenpixel--
--shalem ghuff
{
	agents = {SHALEM, GHUFF},
	dialogue = {
		{GHUFF, "'Shalem 11'?"},
		{SHALEM, "Yes?"},
		{GHUFF, "That's your name?"},
		{SHALEM, "Yes."},
		{GHUFF, "Fair enough."},
	},},

--by Linenpixel--
-- ghuff decker
{
		agents = {GHUFF, DECKER},
		dialogue = {
			{DECKER, "You'd better not get it into your head to start investigating me."},
			{GHUFF, "Are you paying me?"},
			{DECKER, "What? No."},
			{GHUFF, "Then I won't investigate you."},
		},},

--by Linenpixel--
--ghuff decker
{
	agents = {GHUFF, DECKER},
	dialogue = {
		{DECKER, "You know, I considered becoming a private investigator at one point in my life."},
		{GHUFF, "Mm-hmm."},
		{DECKER, "Aren't you going to ask me why I didn't?"},
		{GHUFF, "I think I already know the answer."},
	},},
	
--by Linenpixel--
--edited by Hekateras--
{
	agents = {MIST, INTERNATIONALE},
    dialogue = {
	{MIST, "You have something of a reputation."},
	{INTERNATIONALE, "I can imagine."},
	{MIST, "But so do a lot of people. Come to think of it, half the agency has warned me about the other half."},
	{INTERNATIONALE, "Unfortunately, that sounds about right."},
},},

--by Linenpixel--	
{
agents = {MIST, DRACO},
dialogue = {
    {MIST, "Are you a cyborg? You look a bit like some models I've known."},
    {DRACO, "My existence is both a curse and an enigma, shrouded in dusk and shadow."},
    {MIST, "So... a custom build, then?"},
},},

--by Linenpixel--
{
agents = {MIST, DRACO},
dialogue = {
    {DRACO, "I like the name 'Mist'. It evokes tenebrosity, murkiness, gloaming, brume..."},
    {MIST, "Do you have some kind of thesaurus augment that I'm not aware of?"},
    {DRACO, "No... but I am now contemplating the idea."},
},},

--by Linenpixel--
{
agents = {MIST, DRACO},
dialogue = {
    {DRACO, "I too can go unseen when I wish."},
    {MIST, "From what I've heard, that's not what you're most known for at the agency."},
    {DRACO, "I have many talents. Pray you do not become acquainted with all of them."},
},},

--by Linenpixel--
{
agents = {MIST, DRACO},
dialogue = {
    {MIST, "You know, I don't totally dislike working with you."},
    {DRACO, "Oh? I admit, my curiosity is piqued."},
    {MIST, "When we're together, nobody thinks *I'm* creepy."},
},},

--by Linenpixel--
{
agents = {MIST, PRISM},
dialogue = {
    {PRISM, "If you ever want some help getting back at Plastech, just let me know."},
    {MIST, "What? No, that never occurred to me. I guess revenge is just not my style."},
    {PRISM, "Wow, that is... not how I think at all."},
},},

--by Linenpixel--
{
agents = {MIST, PRISM},
dialogue = {
    {PRISM, "Perception is everything."},
    {MIST, "Seeing is believing."},
    {PRISM, "Enough cliches. Let's get to work."},
},},

--by Linenpixel--
{
agents = {MIST, XU},
dialogue = {
    {MIST, "You're thinking about something technical, aren't you?"},
    {XU, "Is this really the time to be using your abilities?"},
    {MIST, "I wasn't. You were staring into space with a thoughtful expression."},
    {XU, "Oh. Right. Mission. Time to focus."},
},},

--by Linenpixel--
{
 agents = {N_UMI, DRACO},
    dialogue = {
    {DRACO, "Drones are your passion, but they are of no interest to me."},
    {N_UMI, "I wouldn't exactly say..."},
    {DRACO, "There is no life in drones, no veins, no sweet essence that can transcend mortal barriers and, through the alchemy of night, become mine."},
    {N_UMI, "I didn't ask for this information."},
},},

--by Linenpixel--
{
 agents = {N_UMI, INTERNATIONALE},
    dialogue = {
    {INTERNATIONALE, "Welcome to the team. Any tool that we can use when we eventually overthrow the corps is welcome."},
    {N_UMI, "My drones are tools. I'm a person."},
    {INTERNATIONALE, "Sorry. I got carried away. I try to preserve human life, but the revolution will come with a cost."},
    {N_UMI, "Seems I learn more about the people I work with every day."},
},},
	
--by Linenpixel--
{
agents = {GHUFF, DRACO},
dialogue = {
    {GHUFF, "You know, I thought I'd seen it all, but then I met you. Whatever the hell you are."},
    {DRACO, "I am Draco. That is all you need to know."},
    {GHUFF, "It's all I care to know, so we should get along fine."},
},
},
--by Linenpixel--
{
agents = {GHUFF, DRACO},
dialogue = {
    {DRACO, "It is quiet. Dim light illuminates my form, my eternal, unchanging being..."},
    {GHUFF, "Yeah, that might be a problem. The world changes fast. You'd better try to keep up."},
    {DRACO, "It is you who must keep up with me, mortal."},
},
},
	
--by Hekateras--
{
		agents = {PEDLER, XU, SHARP},
		dialogue = {
			{PEDLER, "*I've heard about your history in the sciences. What was your research in, if I may be so bold?*"},
			{XU, "I doubt we have the time, but I will be happy to discuss it with you later."},
			{SHARP, "Fantastic. Now there's two of you."},
			{XU, "Yes, I was just thinking the same thing..."},
		},
	},
	
-- Sombra banter from Talon Recruitment (Overwatch agents mod)
--by WMGreywind-- --edited by Hekateras--

--Sombra Banter

{
        agents = {DECKER, SOMBRA},
        dialogue = {
            {SOMBRA,"Hey, old man, you look like you're ready to fall apart."},
            {DECKER,"Who you calling old, you whippersnapper?"},
            {SOMBRA,"Heh, looks like I stand corrected."},
        },                
    },

--by WMGreywind--	
{
        agents = {DECKER, SOMBRA},
        dialogue = {
            {DECKER,"You think you got enough bells and whistles on that gun of yours, dame?"},
            {SOMBRA,"Hey, at least I get free wi-fi from it."},
            {DECKER,"Hope no one's gonna be able to track that down."},
        },                
    },

--by WMGreywind--
{
        agents = {DECKER, SOMBRA},
        dialogue = {
            {SOMBRA,"You know, you remind me of one of my old co-workers, Decker."},
            {DECKER,"Oh? Did he share my sense of style?"},
            {SOMBRA,"No, but he was always so grumpy."},
			{DECKER,"Everyone's a critic..."},
        },                
    },

	--by WMGreywind--
{
        agents = {INTERNATIONALE, SOMBRA},
        dialogue = {
            {INTERNATIONALE,"Sombra, it's a pleasure to be working with a fellow Anti-Corporatist."},
            {SOMBRA,"I didn't know I had a fan here in Invisible."},
            {INTERNATIONALE,"Your work in exposing the corruption of LumeriCo to the public is known throughout the resistance."},
			{SOMBRA,"Ha, what can I say? I had a lot of help in that."},
        },                
    },
--by WMGreywind--
{
        agents = {INTERNATIONALE, SOMBRA},
        dialogue = {
            {INTERNATIONALE,"You should join me in helping to usher in the global revolution. With your skills, the resistance would be unstoppable."},
            {SOMBRA,"Thanks for the offer, but I'm more for looking out for myself."},
            {INTERNATIONALE,"That's unfortunate to hear. If you ever want a cause greater than yourself, I'll be waiting."},
        },                
    },
--by WMGreywind--
{
        agents = {INTERNATIONALE, SOMBRA},
        dialogue = {
            {SOMBRA,"I've read your file, Maria. Quite the hacker, are you?"},
            {INTERNATIONALE,"I'm not one to brag, but I do believe my skills are second to none."},
            {SOMBRA,"Well, maybe not second to none..."},
        },                
    },
--by WMGreywind--	
{
        agents = {NIKA, SOMBRA},
        dialogue = {
            {NIKA,"..."},
		    {SOMBRA,"Hey, you mind telling me why you're staring at me?"},
            {NIKA,"... I don't trust you."},
            {SOMBRA,"Why don't you tell me something I don't know?"},
        },                
    },
--by WMGreywind--
{
        agents = {NIKA, SOMBRA},
        dialogue = {
            {NIKA,"Central put a lot of trust in you when she let you join. You had better not disappoint her."},
		    {SOMBRA,"Come on now, why don't you lighten up a little? Is that any way to talk to your co-worker?"},
            {NIKA,"If you do anything to betray the agency, I will break you."},
            {SOMBRA,"Are all of you bodyguarding types this uptight?"},
        },                
    },
--by WMGreywind--	
{
        agents = {XU, SOMBRA},
        dialogue = {
            {XU,"Are you ready for another bout of exploring unprotected corporate files?"},
		    {SOMBRA,"You always know what to say to cheer me up, Tony."},
            {XU,"Indeed. It's rare to find a kindred spirit in unsanctioned exploratory hacking."},
            {SOMBRA,"And to think that Central considers these little data trips a liability..."},
        },                
    },
--by WMGreywind--	
{
        agents = {MONSTER, SOMBRA},
        dialogue = {
            {MONSTER,"You know, you're the last person I expected to get roped in to all this Invisible business."},
		    {SOMBRA,"Hey, sometimes you just got to work with what you're given."},
            {MONSTER,"How did she manage to recruit you? I imagine you didn't undersell yourself."},
            {SOMBRA,"Let's just say she aligns a lot better for me than my previous employers."},
        },                
    },
--by WMGreywind--	
{
        agents = {MONSTER, SOMBRA},
        dialogue = {
            {MONSTER,"I've heard of you. I was under the impression you were working with Talon."},
		    {SOMBRA,"Had a bit of a change of employers. You know, basic stuff."},
            {MONSTER,"I was starting to wonder what happened to my preferred source of intel when you went dark for a while."},
            {SOMBRA,"What can I say? Central keeps me busy."},
        },                
    },
--by WMGreywind--	
{
        agents = {MONSTER, SOMBRA},
        dialogue = {
            {SOMBRA,"Monst3r, I got you the latest data packet you requested."},
		    {MONSTER,"Oh did you now? I knew I could count on you to sniff out what I was looking for."},
            {SOMBRA,"So the usual rate?"},
            {MONSTER,"Of course. Let us deal with the mission first, and I shall wire you the credits when we're done."},
        },                
    },
	

--by Linenpixel--
{
agents = {NIKA, GHUFF},
dialogue = {
    {GHUFF, "I enjoy working with someone who knows how to get a job done."},
    {NIKA, "I am the same. I hope we will not disagree on what constitutes \"done\"."},
    {GHUFF, "So do I."},
},
},
--by Linenpixel--
{
agents = {NIKA, GHUFF},
dialogue = {
    {NIKA, "Your augment is useful for detecting threats."},
    {GHUFF, "It's handy for a lot of things."},
    {NIKA, "Of course, I am simply prepared for an attack from all directions at all times."},
    {GHUFF, "I've noticed."},
},
},
--by Linenpixel--
{
agents = {NIKA, GHUFF},
dialogue = {
    {GHUFF, "Have you ever considered relaxing?"},
    {NIKA, "I relax when I'm off duty."},
    {GHUFF, "Yeah, that's totally why people plan their movements to avoid giving the impression that they're sneaking up on you."},
},
},
--by Linenpixel--
{
agents = {DRACO, GHUFF},
dialogue = {
    {DRACO, "Listen to the silence. In it is the sound of the night's hunger."},
    {GHUFF, "Are you for real?"},
    {DRACO, "Is your shadow real?"},
    {GHUFF, "What does that even- you know what? Forget it."},
},
},
--by Linenpixel--
{
agents = {XU, GHUFF},
dialogue = {
    {XU, "A new location! Fresh opportunities for research."},
    {GHUFF, "That's an interesting way of saying that we're breaking so many laws that a lawyer could retire just from listing them all."},
    {XU, "Everything is a research opportunity if you look at it the right way."},
    {GHUFF, "And it must sure be nice to be able to look at it that way."},
},
},
--by Linenpixel--
{
agents = {BANKS, N_UMI},
dialogue = {
    {BANKS, "Have we run into any fun tech that you made, so far?"},
    {N_UMI, "Well... you must understand that at Sankaku I worked as part of a team. You can't really say I made any one particular thing..."},
    {BANKS, "Do you not want to talk about it? I understand. I'll stop talking now."},
},
},
--by Linenpixel--
{
agents = {BANKS, N_UMI},
dialogue = {
    {BANKS, "Do you know that daemons make a noise like caterpillars when they eat through your brain?"},
    {N_UMI, "I'm not a neuroscientist. Or a programmer. You should ask some of them."},
    {BANKS, "I've tried. All they do is say that daemons don't work like that."},
},
},
--by Linenpixel--
{
agents = {BANKS, N_UMI},
dialogue = {
    {BANKS, "If I ever come across something that could be your lost memories, I'll let you know."},
    {N_UMI, "Thanks. But I don't think-"},
    {BANKS, "You never know. They could be hiding in a door somewhere. Or an exec terminal. Even the corps don't understand everything they do."},
},
},
--by Linenpixel--
{
agents = {BANKS, N_UMI},
dialogue = {
    {BANKS, "You actually want your memories back? I'd like to lose some of mine."},
    {N_UMI, "Yes. I have my reasons."},
    {BANKS, "Of course, you lost yours entirely. Maybe I don't want mine gone. Maybe I just want them to be better organized."},
},
},
--by Linenpixel--
{
agents = {BANKS, N_UMI},
dialogue = {
    {N_UMI, "Do you happen to know anything about the O'Connell Street mass drone malfunction incident?"},
    {BANKS, "Oh, yeah, I know about that. Friends of mine."},
    {N_UMI, "Really? Wait, do you mean you think the drones were your friends, or that friends of yours were responsible?"},
    {BANKS, "The latter. And no, I won't tell you how they did it."},
},
},
--by Linenpixel--
{
agents = {INTERNATIONALE, N_UMI},
dialogue = {
    {INTERNATIONALE, "Has any project you worked on ever killed people by accident?"},
    {N_UMI, "By accident?"},
    {INTERNATIONALE, "I'm assuming I already know the answer for 'by design'."},
    {N_UMI, "Unfortunately, yes. On both counts."},
    {INTERNATIONALE, "Thank you. I appreciate your honesty."},
},
},
--by Linenpixel--
{
agents = {MIST, PRISM},
dialogue = {
    {MIST, "I saw the vid you were in. The historical one."},
    {PRISM, "Great."},
    {MIST, "I know there are some inaccuracies, but I don't remember much of the Wars myself, so-"},
    {PRISM, "For someone who can read minds, you're really not good at reading a room, are you?"},
},
},
--by Linenpixel--
{
agents = {MIST, BANKS},
dialogue = {
    {MIST, "I don't know much about what happened in Dublin. It's hard to find reliable info."},
    {BANKS, "Talk to me about jellyfish."},
    {MIST, "Um, I know a lot more about sea anemones."},
    {BANKS, "Right. They sound beautiful. Tell me all about them."},
},
},
--by Linenpixel--
{
agents = {MIST, SHARP},
dialogue = {
    {MIST, "I've met cyborgs, augletes, people with all kinds of enhancements, and most of them aren't like you."},
    {SHARP, "Of course not."},
    {MIST, "That wasn't a compliment."},
    {SHARP, "You think I care?"},
},
},
--by Linenpixel--
{
agents = {MIST, SHARP},
dialogue = {
    {SHARP, "I suppose you can access my mind. But that is too trifling to be a weakness."},
    {MIST, "I can, but I don't want to."},
    {SHARP, "Ha! I defeat you without even trying."},
    {MIST, "You misunderstand. From the scraps I've picked up, it's mostly boring. And repetitive. And predictable."},
},
},
--by Linenpixel--
{
agents = {MIST, RUSH},
dialogue = {
    {MIST, "I've seen several documentaries about you. Some of them are a bit hard to find, but-"},
    {RUSH, "And I can see my face in the mirror every morning without even trying! What was your point?"},
    {MIST, "...Never mind."},
},
},
--by Linenpixel--
 {
agents = {SHALEM, MIST},
dialogue = {
    {MIST, "What's it like to not feel any pain when you kill someone?"},
    {SHALEM, "...I'm a professional. And I don't go poking my nose into your business."},
    {MIST, "No, I mean that literally. What is it like to not experience other people's physical pain?"},
},
},
--by Linenpixel--
{
agents = {SHALEM, MIST},
dialogue = {
    {MIST, "We might have more in common than you think."},
    {SHALEM, "Please, don't feel obliged to make conversation."},
    {MIST, "We were both turned into weapons by forces beyond our control."},
    {SHALEM, "The fact that you'd say that shows how little you know me."},
},
},
--by Linenpixel--
{
agents = {SHALEM, N_UMI},
dialogue = {
    {N_UMI, "Did you get that good with your rifle just from experience?"},
    {SHALEM, "Great, another person who wants to talk about my past."},
    {N_UMI, "Your accuracy rivals that of drones, and yet you haven't even taken advantage of every augment on the market."},
    {SHALEM, "Oh. You want to talk shop. That's different."},
},
},
--by Linenpixel--
{
agents = {MIST, CENTRAL},
dialogue = {
    {MIST, "I can't read you. All I'm picking up is a sort of low-level buzz of caution... almost paranoia."},
    {CENTRAL, "I know you can't. And I don't necessarily consider paranoia a disadvantage. Rather the opposite, in fact."},
    {MIST, "Oh. I suppose I could have figured that out without my abilities."},
    {CENTRAL, "Yes. All you had to do was pay attention."},
},
},
--by Linenpixel--
{
agents = {MIST, CENTRAL},
dialogue = {
    {CENTRAL, "Remember, these missions are not the place for personal agendas. Put your own history with the corps aside."},
    {MIST, "Of course. If all the other agents can do that, I can."},
    {CENTRAL, "...I'm glad to hear it."},  
},
},
--by Linenpixel--
 {
agents = {GHUFF, XU},
dialogue = {
    {GHUFF, "Be prepared to improvise."},
    {XU, "Ah, and this is why I left academia."},
    {GHUFF, "Excuse me?"},
    {XU, "Let's just say the university did not always reward an improvisational spirit."},
    {GHUFF, "On second thought, run any new ideas by me first, okay?"},
},
},
--by Linenpixel--
{
agents = {GHUFF, XU},
dialogue = {
    {GHUFF, "If something goes wrong here, it's not going to be just a broken test tube."},
    {XU, "You don't even know my field, do you? And I've worked with extremely expensive equipment."},
    {GHUFF, "Yeah, that was definitely my point."},
    {XU, "My point is, I can be careful."},
    {GHUFF, "Good."},
},
},	
 


--by Linenpixel--
{
agents = {NIKA, GHUFF},
dialogue = {
    {GHUFF, "I enjoy working with someone who knows how to get a job done."},
    {NIKA, "I am the same. I hope we will not disagree on what constitutes \"done\"."},
    {GHUFF, "So do I."},
},
},
--by Linenpixel--
{
agents = {NIKA, GHUFF},
dialogue = {
    {NIKA, "Your augment is useful for detecting threats."},
    {GHUFF, "It's handy for a lot of things."},
    {NIKA, "Of course, I am simply prepared for an attack from all directions at all times."},
    {GHUFF, "I've noticed."},
},
},
--by Linenpixel--
{
agents = {NIKA, GHUFF},
dialogue = {
    {GHUFF, "Have you ever considered relaxing?"},
    {NIKA, "I relax when I'm off duty."},
    {GHUFF, "Yeah, that's totally why people plan their movements to avoid giving the impression that they're sneaking up on you."},
},
},
--by Linenpixel--
{
agents = {DRACO, GHUFF},
dialogue = {
    {DRACO, "Listen to the silence. In it is the sound of the night's hunger."},
    {GHUFF, "Are you for real?"},
    {DRACO, "Is your shadow real?"},
    {GHUFF, "What does that even- you know what? Forget it."},
},
},
--by Linenpixel--
 {
agents = {XU, GHUFF},
dialogue = {
    {XU, "A new location! Fresh opportunities for research."},
    {GHUFF, "That's an interesting way of saying that we're breaking so many laws that a lawyer could retire just from listing them all."},
    {XU, "Everything is a research opportunity if you look at it the right way."},
    {GHUFF, "And it must sure be nice to be able to look at it that way."},
},
},

--by Linenpixel--
{
agents = {BANKS, N_UMI},
dialogue = {
    {BANKS, "Have we run into any fun tech that you made, so far?"},
    {N_UMI, "Well... you must understand that at Sankaku I worked as part of a team. You can't really say I made any one particular thing..."},
    {BANKS, "Do you not want to talk about it? I understand. I'll stop talking now."},
},
},

--by Linenpixel--
 {
agents = {BANKS, N_UMI},
dialogue = {
    {BANKS, "Do you know that daemons make a noise like caterpillars when they eat through your brain?"},
    {N_UMI, "I'm not a neuroscientist. Or a programmer. You should ask some of them."},
    {BANKS, "I've tried. All they do is say that daemons don't work like that."},
},
},
--by Linenpixel--
 {
agents = {BANKS, N_UMI},
dialogue = {
    {BANKS, "If I ever come across something that could be your lost memories, I'll let you know."},
    {N_UMI, "Thanks. But I don't think-"},
    {BANKS, "You never know. They could be hiding in a door somewhere. Or an exec terminal. Even the corps don't understand everything they do."},
},
},
--by Linenpixel--
{
agents = {BANKS, N_UMI},
dialogue = {
    {BANKS, "You actually want your memories back? I'd like to lose some of mine."},
    {N_UMI, "Yes. I have my reasons."},
    {BANKS, "Of course, you lost yours entirely. Maybe I don't want mine gone. Maybe I just want them to be better organized."},
},
},
--by Linenpixel--
 {
agents = {BANKS, N_UMI},
dialogue = {
    {N_UMI, "Do you happen to know anything about the O'Connell Street mass drone malfunction incident?"},
    {BANKS, "Oh, yeah, I know about that. Friends of mine."},
    {N_UMI, "Really? Wait, do you mean you think the drones were your friends, or that friends of yours were responsible?"},
    {BANKS, "The latter. And no, I won't tell you how they did it."},
},
},
--by Linenpixel--
{
agents = {INTERNATIONALE, N_UMI},
dialogue = {
    {INTERNATIONALE, "Has any project you worked on ever killed people by accident?"},
    {N_UMI, "By accident?"},
    {INTERNATIONALE, "I'm assuming I already know the answer for 'by design'."},
    {N_UMI, "Unfortunately, yes. On both counts."},
    {INTERNATIONALE, "Thank you. I appreciate your honesty."},
},
},
--by Linenpixel--
 {
agents = {MIST, PRISM},
dialogue = {
    {MIST, "I saw the vid you were in. The historical one."},
    {PRISM, "Great."},
    {MIST, "I know there are some inaccuracies, but I don't remember much of the Wars myself, so-"},
    {PRISM, "For someone who can read minds, you're really not good at reading a room, are you?"},
},
},
--by Linenpixel--
 {
agents = {MIST, BANKS},
dialogue = {
    {MIST, "I don't know much about what happened in Dublin. It's hard to find reliable info."},
    {BANKS, "Talk to me about jellyfish."},
    {MIST, "Um, I know a lot more about sea anemones."},
    {BANKS, "Right. They sound beautiful. Tell me all about them."},
},
},
--by Linenpixel--
 {
agents = {MIST, SHARP},
dialogue = {
    {MIST, "I've met cyborgs, augletes, people with all kinds of enhancements, and most of them aren't like you."},
    {SHARP, "Of course not."},
    {MIST, "That wasn't a compliment."},
    {SHARP, "You think I care?"},
},
},
--by Linenpixel--
{
agents = {MIST, SHARP},
dialogue = {
    {SHARP, "I suppose you can access my mind. But that is too trifling to be a weakness."},
    {MIST, "I can, but I don't want to."},
    {SHARP, "Ha! I defeat you without even trying."},
    {MIST, "You misunderstand. From the scraps I've picked up, it's mostly boring. And repetitive. And predictable."},
},
},
--by Linenpixel--
 {
agents = {MIST, RUSH},
dialogue = {
    {MIST, "I've seen several documentaries about you. Some of them are a bit hard to find, but-"},
    {RUSH, "And I can see my face in the mirror every morning without even trying! What was your point?"},
    {MIST, "...Never mind."},
},
},

 --by Linenpixel--
 {
agents = {PEDLER, SHARP},
dialogue = {
{PEDLER, "*If you ever want to make more changes, feel free to consult your friendly local expert on living in a robot body.*"},
{SHARP, "You, an expert? Pshaw."},
{PEDLER, "*Do I detect a hint of jealousy?*"},
{SHARP, "No."},
},
},
--by Linenpixel--
{
agents = {MIST, SHARP},
dialogue = {
{MIST, "I've never seen you smile."},
{SHARP, "Few have seen my perfect form at all. Consider yourself lucky."},
{MIST, "I don't even know if you have teeth."},
{SHARP, "Titanium and zirconia."},
},
},
--by Linenpixel--
{
agents = {MIST, SHARP},
dialogue = {
{SHARP, "Become at least 25 percent non-flesh, and I might consider talking to you."},
{MIST, "What a tempting offer. It'll be so hard to turn it down."},
{SHARP, "Oh, so they actually taught you sarcasm in that lab?"},
{MIST, "I thought you weren't talking to me."},
},
},

--by Linenpixel--
 {
agents = {MIST, NIKA},
dialogue = {
{NIKA, "Our enemies don't see you. I am the last thing they see."},
{MIST, "Was that a quip?"},
{NIKA, "..."},
},
},
--by Linenpixel--
 {
agents = {MIST, RUSH},
dialogue = {
{MIST, "You know, Plastech is bringing a lot of new, low-risk augments onto the market."},
{RUSH, "And why should I care?"},
{MIST, "I was just mentioning it."},
{RUSH, "You seem to have me confused with someone else."},
},
},
--by Linenpixel--
 {
agents = {MIST, RUSH},
dialogue = {
{MIST, "So, if I was thinking of getting some more augments-"},
{RUSH, "Are you planning on becoming one of the most amazing athletes ever?"},
{MIST, "No, I-"},
{RUSH, "Then none of my advice will be relevant to you."},
},
},
--by Linenpixel--
 {
agents = {MIST, BANKS},
dialogue = {
{MIST, "Is someone thinking about... sharks?"},
{BANKS, "What? No, not me."},
{MIST, "Wait, that's me. Sorry. Things can get confusing... like echoes..."},
{BANKS, "I know what you mean."},
},
},
--by Linenpixel--
{
agents = {NIKA, GHUFF},
dialogue = {
{NIKA, "You locate threats, I destroy them. Plan?"},
{GHUFF, "Sounds good. As long as you don't get too carried away with the destruction."},
{NIKA, "Right. Conserve energy."},
},
},
--by Linenpixel--
{
agents = {N_UMI, SHARP},
dialogue = {
{N_UMI, "You had the beginnings of a promising academic career. I can't understand why you abandoned it."},
{SHARP, "A better opportunity presented itself."},
{N_UMI, "Murdering people?"},
{SHARP, "You built technology that murdered people. I became technology and murdered people. The only difference is I am now better-looking."},
},
},
--by Linenpixel--
 {
agents = {N_UMI, SHARP},
dialogue = {
{SHARP, "I've heard you talking to your drones."},
{N_UMI, "Something doesn't have to be sapient for me to talk to it."},
{SHARP, "Ha. So you're foolish and sentimental."},
{N_UMI, "Maybe so. But just because I talk to something doesn't mean I won't kill it."},
},
},

--by Hekateras--
 {
agents = {DECKER, CARMEN},
dialogue = {
	{DECKER, "< grumble > "},
	{CARMEN, "You okay there, old-timer?"},
	{DECKER, "Nice hat."},
	{CARMEN, "Thanks! I stole it myself."},
	},},

--by Hekateras--
{
agents = {NIKA, CARMEN},
dialogue = {
	{CARMEN, "You're the one who saved Player, weren't you? The one who got him out when the corps were closing in."},
	{NIKA, "The hacker? I was following her orders. What of it?"},
	{CARMEN, "Still. Thank you."},
	{NIKA, "You are welcome."},
	},},

		
 -- Carmen banters by Grey, edits by Hek
--by WMGreywind--
{
agents = {DECKER, CARMEN},
dialogue = {
	{DECKER, "If I was in charge of security here, none of us would have gotten past the elevator."},
	{CARMEN, "And if I was infiltrating, you'd have gotten my calling card."},
	{DECKER, "Bah. You underestimate how good I was at my job."},
	{CARMEN, "Clearly not good enough to keep it."},
	},},
 
--by WMGreywind--
 {
agents = {DECKER, CARMEN},
dialogue = {
		{CARMEN,"Is it just me or is security starting to get tighter all of a sudden?"},
		{DECKER,"Tighter? Back in my day, you couldn’t even take a smoke break without upper management knowing."},
		{CARMEN,"...Aren't you, like, 38?"},
		{DECKER,"...Yeah, what's your point?"},
		},},

--by WMGreywind--
{
agents = {DECKER, CARMEN},
dialogue = {
		{DECKER,"Great. Another thief who can't keep her hands to herself. I better not catch you picking my pockets."},
		{CARMEN,"Why not? Worried I'll swipe your precious whiskey?"},
		{DECKER,"No. This coat cost me over half a million credits. I don't want you and your wandering hands tearing it up, is all."},
		{CARMEN,"...Wow. Say goodbye to your whiskey, then."},
 },},
 
--by WMGreywind-- 
{
agents = {SHALEM, CARMEN},
dialogue = {
	{CARMEN,"I can't believe I’m stuck working with a murderer like you."},
	{SHALEM,"I don't care what you believe, only if you can get the job done."},
	{CARMEN,"Of course I can get the job done, I just find it sickening to work with you."},
	{SHALEM,"Whatever. Just don't let your reservations get us killed."},
},},
  
--by WMGreywind-- 
{
agents = {SHALEM, CARMEN},
dialogue = {
	{SHALEM, "You still owe me an apology for job you messed up for me back in Monaco."},
	{CARMEN, "What do I have to apologise for? Did saving the life of that guard really mess things up so badly?"},
	{SHALEM, "Sharp and I were nearly captured."},
	{CARMEN, "I wasn't on the team then, so I don't see why I'd need to apologise."},
 
},},

--by WMGreywind-- 
{
agents = {SHALEM, CARMEN},
dialogue = {
	{CARMEN, "Is violence really your answer to everything?"},
	{SHALEM, "It's an option, like many other things. I happen to rely on solutions that deal with a problem permanently."},
	{CARMEN, "But those \"problems\" are people! How could you even think about killing someone?"},
	{SHALEM, "In case you've forgotten, ma'am, I am an assassin. Killing is literally part of the job."},
},},

--by WMGreywind-- 
{
agents = {SHALEM, CARMEN},
dialogue = {
	{SHALEM, "So what did I do to deserve the stares?"},
	{CARMEN, "I'm just trying to figure out what kind of man could so callously steal a person's life."},
	{SHALEM, "How rich, a thief berating me for stealing."},
	{CARMEN, "At least I can still return what I steal."},
},},


--by WMGreywind-- 
 {
agents = {BANKS, CARMEN},
dialogue = {
	{BANKS, "You know, Red, this reminds me of the time we met back in Amsterdam. I can't believe we both got stuck in that elevator."},
	{CARMEN, "Out of all the ways to almost get caught, stuck in an elevator wasn't really top of my list."},
	{BANKS, "Still, we got away, didn't we? I know there are plenty of orphanages back in Dublin Nua that were happy to get that money."},
	{CARMEN, "Quite the lucky coincidence we were both there on the same night, then."},
},},


--by WMGreywind-- 
{
agents = {BANKS, CARMEN},
dialogue = {
	{BANKS, "Oh, hi Red! I didn't see you there? When did you get here?"},
	{CARMEN, "I've been here all along, Joles. Are you okay?"},
	{BANKS, "Just peachy, Red! Peachy and squeaky like the walls!"},
	{CARMEN, "Alright. Well, just follow my lead, Joles. I'll make sure we get through this."},
},},

--by WMGreywind-- 
{
agents = {BANKS, CARMEN},
dialogue = {
	{BANKS, "Ugh... My head is pounding, Red. I think my brain chip's acting up again."},
	{CARMEN, "Why did you even get it if it's been causing you so much trouble? You seemed to manage well enough without it."},
	{BANKS, "The corps won't slow down for us, and neither can we, Red. We've got to adapt to survive. Even if it hurts."},
},},

--by WMGreywind-- 
{
agents = {XU, CARMEN},
dialogue = {
	{XU, "Interesting. Some curious tech you've got in that coat, Miss."},
	{CARMEN, "Yep, it's all custom-made. Gotten me out of more jams than I can count."},
	{XU, "Do you mind if I take a closer look at that laser? I promise you, I won't break it. Not intentionally, anyway."},
	{CARMEN, "Yeah... I think I'd prefer we kept this to demonstrations only."},
},},

--by WMGreywind-- 
{
agents = {XU, CARMEN},
dialogue = {
	{CARMEN, "So what's someone like you doing working for an agency like Invisible?"},
	{XU, "I'm afraid I got a little too careless in my youth. Tampered with some things I didn't technically have legal access to."},
	{CARMEN, "Really? Were you looking for dirt on one of the corps, or trying to sabotage them?"},
	{XU, "Hm? No. I was bored, and K&O's secure servers seemed like a nice diversion. And they were. Albeit a costly one."},
},},

--by WMGreywind-- 
{
agents = {XU, CARMEN},
dialogue = {
	{XU, "You really should introduce me to your friend, Miss Sandiego. I always enjoy swapping notes with someone tech-savvy."},
	{CARMEN, "Sorry, Central told me I need to keep Player out of this whole business. He'd probably like to meet you as well."},
	{XU, "I see, my apologies, then. Central is quite adamant on having things done her way, yes?"},
	{CARMEN, "She's the whole reason Player's still around. She can be as adamant as she likes."},
},},

--by WMGreywind-- 
{
agents = {NIKA, CARMEN},
dialogue = {
	{NIKA, "Your fighting technique is good. Do you have previous training?"},
	{CARMEN, "Yeah, one of the people who raised me taught me pretty well. She was a tough instructor, but she knew it'd help me survive."},
	{NIKA, "I see. I would like to meet her someday for a friendly spar. See if she is as good as you say."},
	{CARMEN, "...I don't think sparring is much of an option for her these days."},
},},


--by WMGreywind-- 
{
agents = {NIKA, CARMEN},
dialogue = {
	{NIKA, "What is the matter? You look uneasy."},
	{CARMEN, "I just don't know how any of you can do it. How you can take someone's life."},
	{NIKA, "...It is not an easy thing to do, Carmen. You should be thankful you haven't had to make that choice."},
	{CARMEN, "I hope I never have to."},
},},


--by WMGreywind-- 
{
agents = {SHARP, CARMEN},
dialogue = {
	{SHARP, "I don't think things can get any more wretched now that I'm forced to work with you."},
	{CARMEN, "Hey, I'm not over the moon with this either."},
	{SHARP, "Just stay out of my way. I don't need some misguided moral busybody telling me what to do."},
	{CARMEN, "As long as you keep yourself under control, gearhead."},
},},

--by WMGreywind-- 
{
agents = {SHARP, CARMEN},
dialogue = {
	{CARMEN, "Don't you think you should be a bit more careful?"},
	{SHARP, "Careful? Me? Preposterous! What need I fear from the pathetic meatbags the corps have foolishly sent our way?"},
	{CARMEN, "Well, just remember: Pride goes before the fall."},
	{SHARP, "Bah! The only fall here will be the thud of bodies of those that dare oppose me!"},
},},

--by WMGreywind-- 
{
agents = {SHARP, CARMEN},
dialogue = {
	{SHARP, "You have my pity, meatbag."},
	{CARMEN, "Your pity? Why's that?"},
	{SHARP, "It must be so bothersome to have to grab all your gadgets when you could so easily have them installed into your hands!"},
	{CARMEN, "I prefer to keep my hands as they are, thank you very much."},
},},

--by WMGreywind-- 
{
agents = {MONSTER, CARMEN},
dialogue = {
	{MONSTER, "You really must tell me how you manage to get your hands on such quality toys, Carmen. Imagine the profit margins from licensing such technology."},
	{CARMEN, "Sorry, but these gadgets aren't for sale. I wouldn't want my best tricks falling into the wrong hands, after all."},
	{MONSTER, "Unfortunate. You're really missing out on a business opportunity here."},
	{CARMEN, "Well, maybe there's more to life than business opportunities."},
},},

--by WMGreywind-- 
{
agents = {MONSTER, CARMEN},
dialogue = {
	{MONSTER, "So how did Gladstone ever manage to recruit someone as elusive as yourself? Seems like you would have preferred to remain a freelancer."},
	{CARMEN, "She helped me out when it mattered, and now I owe her a favour. At least it's not as bad as I thought it would be."},
	{MONSTER, "Really now? Gladstone means well, but you should be careful about staying indebted to her for too long."},
	{CARMEN, "I'll keep that in mind."},
},},


--by WMGreywind-- 
{
agents = {CENTRAL, CARMEN},
dialogue = {
	{CARMEN, "There's something that's been bugging me for a big. How were you able to get to Player before the corps did?"},
	{CENTRAL, "I've been keeping tabs on you ever since you started making a name for yourself."},
	{CARMEN, "So you were spying on me."},
	{CENTRAL, "Of course I was. Did you think I was the one running your fan club?"},
},},

--by WMGreywind-- 
{
agents = {CENTRAL, CARMEN},
dialogue = {
	{CENTRAL, "It's a pity you didn't join the team sooner, Carmen. We could have done a good deal of damage if I had had you from day one."},
	{CARMEN, "You didn't make a good impression. How was I supposed to know you were more than just a bunch of hired goons?"},
	{CENTRAL, "You weren't. It's how we have avoided unwanted attention for so long."},
	{CARMEN, "I guess I just enjoy being the center of attention too much."},
},},


--by WMGreywind-- 
{
agents = {DRACO, CARMEN},
dialogue = {
	{DRACO, "Bold colours for a stealth mission."},
	{CARMEN, "Don't you have a gun? Those are loud."},
	{DRACO, "Then we shall do this the memorable way."},
	{CARMEN, "I'm not sure we're on the same page, buddy."},
},},


--by WMGreywind-- 
{
agents = {DRACO, CARMEN},
dialogue = {
	{DRACO, "Swift moves, light steps, steady hands. Consider me impressed."},
	{CARMEN, "You sound like someone I know."},
	{DRACO, "The Scarlet Shadow who knew no fear; wherever she went, she left behind only broken hearts, and empty pockets."},
	{CARMEN, "You definitely sound like someone I know."},
},},


--by WMGreywind-- 
{
agents = {RUSH, CARMEN},
dialogue = {
	{RUSH, "You're pretty fast, but you should ditch the coat."},
	{CARMEN, "I'm not ditching my coat. It's got all my stuff in it."},
	{RUSH, "Your loss. Don't blame me when you get stuck in a door."},	
},},

--by WMGreywind-- 
{
agents = {RUSH, CARMEN},
dialogue = {
		{CARMEN, "Slow down! Are you trying to get yourself caught?"},
		{RUSH, "What's the matter? Scared of a few pedestrians with guns?"},
		{CARMEN, "I'd rather not make a scene before the mission has even started."},
		{RUSH, "And here I thought you would be fun."},
},},

--by WMGreywind-- 
{
agents = {CONWAY, CARMEN},
dialogue = {
	{CONWAY, "Hey, toots, really digging the hat and coat. It's always a joy to meet a fellow hat fancier."},
	{CARMEN, "You've got a pretty fancy hat and coat there yourself. You wear it for style, or...?"},
	{CONWAY, "What, like Decker? 'Course not. I like to keep things practical."},
	{CARMEN, "That makes two of us."},
},},

 --by Hekateras-- inspired by Greywind
 {
 agents = {PRISM, CARMEN},
 dialogue = {
 {PRISM, "So, you want to exchange autographs sometime? You could have mine, I could have yours..."},
{CARMEN, "I didn't think you'd care about autographs."},
{PRISM, "Not usually."}
}, },
 
--by Hekateras-- inspired by Greywind
{
 agents = {PRISM, CARMEN},
 dialogue = {
 {PRISM, "You know, I was offered a part in a series about you once."},
 {CARMEN, "You're kidding."},
 {PRISM, "Truth. The industry loves people who can make a splash, even if they're criminals."},
 {CARMEN, "You mean especially if they're criminals. Isn't that how you got your most famous role?"},
 {PRISM, "Can't argue with that."},
 
 },},
  
 --Age of Lever banters
 --by Hekateras--
 {
  agents = {ELIAS, PIKER, SOPHIE},
  dialogue = {
	{ELIAS, "Try not to go loco this time."},
	{PIKER, "Who put you in charge?"},
	{ELIAS, "I'll tell Sophie."},
	{PIKER, "Alright, fine, take it easy!"},
	},},
  
 --by Hekateras--
 {
  agents = {ELIAS, PIKER},
  dialogue = {
	{ELIAS, "Stick to the plan, Piker. Remember how you almost got us killed?"},
	{PIKER, "\"Almost\" doesn't count."},
	{ELIAS, "Piker, I'm serious..."},
	{PIKER, "Get over it, you big baby."},
	},},
  
 --by Hekateras--
 {
  agents = {ELIAS, SOFTSON},
  dialogue = {
	{ELIAS, "What'd I tell you about trying to take on goons on your own?"},
	{SOFTSON, "Get off my back, man. I got skills, too."},
	{ELIAS, "Uh-huh."},
	{SOFTSON, "Do not let doubt into your heart, brother."},
	},},
  
 --by Hekateras--
 {
  agents = {ELIAS, SOFTSON},
  dialogue = {
	{SOFTSON, "Here we are. Now everyone's gonna know what age it is."},
	{ELIAS, "Don't say it..."},
	{SOFTSON, "Age of the geek, baby."},
	{ELIAS, "Damn it, Softson!"},
	},},
  
 --by Hekateras--
 {
  agents = {ELIAS, SOFTSON},
  dialogue = {
	{SOFTSON, "Assessing the blueprints... bam."},
	{ELIAS, "Not bad. You learn all that in your mom's basement?"},
	{SOFTSON, "Not even close. *Your* mom says hi, by the way. Zing!"},
	{ELIAS, "That's not... you're not supposed to... Ugh, forget it."},
	},},
  
 --by Hekateras--
 {
  agents = {ELIAS, NATE},
  dialogue = {
	{ELIAS, "I don't like this, Nate."},
	{NATE, "Something bothering you?"},
	{ELIAS, "We don't do heists with this little prep. Things turn for the worst, what do you do?"},
	{NATE, "Let you off the leash, I imagine."},
	},},
  
 --by Hekateras--
 {
  agents = {NATE, SOPHIE, PIKER},
  dialogue = {
	{NATE, "Pay attention, people. This isn't going to be easy."},
	{SOPHIE, "Oooh, I love it when it gets all slippery."},
	{PIKER, "Yeah, beating bad guys is twice the fun like that."},
	{NATE, "Focus."},
	},},
  
 --by Hekateras--
 {
  agents = {NATE, PIKER, SOFTSON},
  dialogue = {
	{NATE, "We're here. Try to play nice."},
	{PIKER, "Hey, I'm nice!"},
	{NATE, "No dangling Softson down an elevator shaft, either."},
	{PIKER, "What, he's not allowed to have fun?"},
	},},
  
 --by Hekateras--
 {
  agents = {NATE, PIKER},
  dialogue = {
	{NATE, "No extracurriculars, Piker."},
	{PIKER, "Is this about last time? I've told you, that antique tiara was *super* shiny."},
	{NATE, "So are their guns."},
	{PIKER, "Mmn, not really. They're, like, three out of ten, tops."},
	},},
  
 --by Hekateras--
 {
  agents = {NATE, SOFTSON},
  dialogue = {
	{NATE, "Remember to apply yourself."},
	{SOFTSON, "You channelin' some preschool teacher now?"},
	{NATE, "Could I run this crew otherwise?"},
	},},
  
 --by Hekateras--
 {
  agents = {NATE, SOFTSON},
  dialogue = {
	{SOFTSON, "Hey. How about next time, you let me do the plan."},
	{NATE, "You still want to design a con like a video game?"},
	{SOFTSON, "Hey, just because the execution was a little off last time doesn't mean-"},
	{NATE, "You got kidnapped by the mark."},
	{SOFTSON, "So there were some kinks to work out, no big deal!"},
	},},
  
 --by Hekateras--
 {
  agents = {SOFTSON, PIKER},
  dialogue = {
	{SOFTSON, "Hey. Let me know next time you go cartwheeling through a laser grid like that, yeah?"},
	{PIKER, "Oh, you want to give it a try?"},
	{SOFTSON, "Oh hell no, I just really like the show."},
	},},
  
 --by Hekateras--
 {
  agents = {SOFTSON, PIKER},
  dialogue = {
	{SOFTSON, "So when you said people are like locks-"},
	{PIKER, "You get it, right? Like an encryption. Sometimes you just have to wait while your little code thing crunches the numbers."},
	{SOFTSON, "Yeah, see, *my* little code thing is a little confused, is all."},
	{PIKER, "I'll let you know when it spits out an answer."},
	},},

 --by Hekateras--
 {
  agents = {SOFTSON, PIKER},
  dialogue = {
	{SOFTSON, "Girl, you and I have got to talk about heights."},
	{PIKER, "I love heights! Let's talk!"},
	{SOFTSON, "Well, you see? Me? Generally not cool with heights. So maybe next time you've got me dangling down an elevator shaft-"},
	{PIKER, "That was fun, huh? You want to go again?"},
	{SOFTSON, "...You know what, alright. If it'll make you happy."},
	},},	

 --by Hekateras--
 {
  agents = {ELIAS, SOFTSON, PIKER},
  dialogue = {
	{ELIAS, "-I'm just saying, maybe switch to a nice suit every once in a while."},
	{SOFTSON, "I've got my own style, man. And besides, Piker likes the way I dress. It's my image."},
	{ELIAS, "She does, huh? Have you tried asking her that?"},
	},},

 --by Hekateras--
 {
  agents = {SOFTSON, PIKER},
  dialogue = {
	{SOFTSON, "I'm just saying, babe, social skills ain't exactly your forte."},
	{PIKER, "That's rubbish. I'm a total people person."},
	{SOFTSON, "Remember when you stabbed that guy with a spork?"},
	{PIKER, "He was threatening me!"},
	{SOFTSON, "He was asking for directions!"},
	},},

 --by Hekateras--
 {
  agents = {ELIAS, SOPHIE},
  dialogue = {
	{SOPHIE, "Be a dear and hold my bag, will you?"},
	{ELIAS, "Fine. Just no hypnotism mumbo-jumbo, okay?"},
	{SOPHIE, "Don't be silly. Hypnotism is Nate's cuppa tea. I only dabble in some neurolinguistic programming-"},
	{ELIAS, "Great, peachy. Hold your own bag!"},
	},},

 --by Hekateras--
 {
  agents = {ELIAS, PIKER},
  dialogue = {
	{PIKER, "Hey, Elias, do you mind if I-"},
	{ELIAS, "Yeah."},
	{PIKER, "You didn't even let me-"},
	{ELIAS, "Nope."},
	},},

	 --by Hekateras--
 {
  agents = {ELIAS, PIKER},
  dialogue = {
	{PIKER, "You think you're so tough?"},
	{ELIAS, "...Piker, you're the thief. You don't have to prove anything to me. We've got different jobs."},
	{PIKER, "I bet I could take you."},
	{ELIAS, " < sigh > "},
	},},

	 --by Hekateras--
 {
  agents = {ELIAS, SOFTSON},
  dialogue = {
	{ELIAS, "You take my sandwich?"},
	{SOFTSON, "We just gone in. Is this really the time?"},
	{ELIAS, "Yeah, maybe I'll ask again next time one of their trained gorillas has a gun on you."},
	{SOFTSON, "So touchy today..."},
	},},

	 --by Hekateras--
 {
  agents = {ELIAS, SOFTSON},
  dialogue = {
	{ELIAS, "Listen, you can fiddle around with your little toys all you want, just keep them away from me."},
	{SOFTSON, "Hey, man, the warning label I put there specifically said \"do not shake\"."},
	{ELIAS, "You're on thin ice here, Softson. Real thin."},
	},},

	 --by Hekateras--
 {
  agents = {ELIAS, SOFTSON},
  dialogue = {
	{SOFTSON, "Remember what I told you. Anyone can 'jack a console, it ain't rocket science."},
	{ELIAS, "Whatever. You still got the karate chop I taught you?"},
	{SOFTSON, "Hey, man, that damn near broke my fingers. Do *you* want to have to type things in for me? I don't think so."},
	},},

	 --by Hekateras--
 {
  agents = {ELIAS, SOFTSON},
  dialogue = {
	{SOFTSON, "Don't worry, you can get back to punching people soon. I'm sure this has been very frustrating for you."},
	{ELIAS, "it's a small jet. I get antsy."},
	{SOFTSON, "A lil bit of cabin fever. I get you, man, I get you."},
	{ELIAS, "Just stay back. Wouldn't want you and your little computer things in the way."},
	},},
	
	 --by Hekateras--
 {
  agents = {SOFTSON, PIKER},
  dialogue = {
	{PIKER, "it's nice, isn't it?"},
	{SOFTSON, "What is, babe?"},
	{PIKER, "Having other people there. To watch you. Have your back."},
	{SOFTSON, "Sure is."},
	},},

	 --by Hekateras--
 {
  agents = {ELIAS, PIKER},
  dialogue = {
	{ELIAS, "Remember what I told you about guns?"},
	{PIKER, "Don't get shot at?"},
	{ELIAS, "Guns, they have a very specific range of accuracy. The other guy gets too close, you get him before he gets you."},
	{PIKER, "Thanks, Gandhi."},
	{ELIAS, "That doesn't even make sense..."},
	},},

 --by Hekateras--
 {
  agents = {SOPHIE, NATE},
  dialogue = {
	{SOPHIE, "Ooh, it's all a bit cloak and dagger, isn't it? You know what it reminds me of?"},
	{NATE, "Florence-"},
	{SOPHIE, "-Geneva.\n\n...It was Geneva, Nate."},
	{NATE, "Oh, don't start."},
	},},	
 
 --by Hekateras--
 {
  agents = {SOFTSON, PIKER},
  dialogue = {
	{PIKER, "I've missed this. The bike of crime."},
	{SOFTSON, "Hey, what we do now is actually legal. Sort of."},
	{PIKER, "Yeah, feels weird. Doesn't that bother you?"},
	{SOFTSON, "It does rankle the pride a little..."},
	},},	
  
 --by Hekateras--
 {
  agents = {NATE, SOFTSON},
  dialogue = {
	{SOFTSON, " < yawn > "},
	{NATE, "You stay up all night playing videogames again?"},
	{SOFTSON, "What? No. It's just the lights, man, can't sleep well with those jet lights, it's a biorhythm thing, and how dare you!"},
	{NATE, "At least you're not skipping out on the job this time."},
	{SOFTSON, "That was ONE time, Nate! One time!"},
	},},	
  
 --by Hekateras--
 {
  agents = {NATE, ELIAS},
  dialogue = {
	{ELIAS, "This place gives me the creeps."},
	{NATE, "You're scared of office buildings now? You?"},
	{ELIAS, "It's the corps, Nate. You know what they do. Ruin lives, kidnap kids to experiment on, and that's just the stuff that gets leaked."},
	{NATE, "And that is why we're here."},
	},},	
 
 --by Hekateras--
 {
  agents = {NATE, PIKER},
  dialogue = {
	{PIKER, "Let's go steal a- What are we stealing, Nate?"},
	{NATE, "Secrets, possibly. Whatever we can get our hands on. We'll know it when we see it."},
	{PIKER, "Let's go steal a mystery!"},
	{NATE, "Acceptable."},
	},},	
 
  --by Hekateras--
 {
  agents = {SOPHIE, NATE},
  dialogue = {
	{NATE, "Hm. Are you thinking what I'm thinking?"},
	{SOPHIE, "The Double-Cherry Jockey? I thought you'd never ask."},
	{NATE, "No, the Double-Cherry Jockey would never work in a place with these LEDs. I was going to suggest-"},
	{SOPHIE, "Do you *really* have to undermine me in *everything* I say?"},
	},},	

 --by Hekateras--
 {
  agents = {SOPHIE, NATE},
  dialogue = {
	{SOPHIE, "Times used to be simpler. I ran, you chased..."},
	{NATE, "And now we're both running. Are you getting nostalgic?"},
	{SOPHIE, "Uh-uh. Things may be more complicated now, but that's just the way I like it."},
	},},	
  	
  --by Hekateras--
 {
  agents = {SOPHIE, NATE},
  dialogue = {
	{NATE, "Now, I know you think you can talk your way out of anything, but please, be careful."},
	{SOPHIE, "Darling, I once pulled a fast one on the mob with nothing but high heels and a pound of licorice."},
	{NATE, "Yeah, well, I'm sure you'll be- \nWait, what do you mean by *nothing* but high heels?"},
	{SOPHIE, "Oh, don't get *jealous*, Nate. I might not be able to resist."},
	},},	
 
 --by Hekateras--
 {
  agents = {SOPHIE, NATE},
  dialogue = {
	{NATE, "Um. Are those the, uh..."},
	{SOPHIE, "The Jimmy Choos you stole for me last week? Of course they are. How could I resist?"},
	{NATE, "Well, you look stunning in them."},
	{SOPHIE, "That is the plan, darling."},
	},},	
	
 --by Hekateras--
 {
  agents = {PIKER, SOFTSON},
  dialogue = {
	{PIKER, "Ooh, I can smell it from here. *Money.*"},
	{SOFTSON, "Take it easy, girl. Still a lot of walls between us and those safes."},
	{PIKER, " < sniff > "},
	},},	
	
 --by Hekateras--
 {
  agents = {NATE, PIKER},
  dialogue = {
	{PIKER, "Huh. You know, I kind of miss having to *actually* infiltrate the building."},
	{NATE, "Alright then, let's make this an exercise. How would you have gotten in?"},
	{PIKER, "Mmmmmmmmm. Probably the vents."},
	{NATE, "Try again. I know for a fact you're more inventive than that."},
	},},

 --by Hekateras--
{
   agents = {ELIAS, SOFTSON},
	dialogue = {
	{ELIAS, "I don't trust this."},
	{SOFTSON, "You, not trusting something? Get outta town."},
	{ELIAS, "This teleporter tech. Probably losing some of my molecules along the way just because it's missing a screw."},
	{SOFTSON, "You, my friend, are well on your way to becoming an old and bitter technophobe."},},	
  	},

 --by Hekateras--
{
   agents = {NATE, PIKER},
	dialogue = {
	{PIKER, "Nate? Naaaaate? Hey Naaaaate!"},
	{NATE, "What? What is it?, Piker?"},
	{PIKER, "Do you think there's a God? Do you think he's to blame for all the bad things?"},
	{NATE, "Luckily, we're here. Focus on the heist."},
  	},},
	
 --by Hekateras--
{
   agents = {NATE, PIKER},
	dialogue = {
	{PIKER, "I still don't get it."},
	{NATE, "It's just a joke, Piker. You don't have to get it."},
	{PIKER, "But if a doctor, a cop and a priest walk into a bar, doesn't that mean they're already in cahoots? I mean, what are the chances they'd all go to the same bar? And if so-"},
	{NATE, "Why don't you ask Sophie to explain that to you?"},
	{PIKER, "Aw, you say that about everything."},
  	},},
	
 --by Hekateras--
{
   agents = {SOPHIE, PIKER},
	dialogue = {
	{SOPHIE, "Alright, now, just like we practised. If you get in trouble...?"},
	{PIKER, "I don't think I can pretend I've twisted my ankle. I mean, who *does* that? Octagenarians?"},
	{SOPHIE, "Nuh-huh, that's not going to fly with me. These are tried-and-true grifter tactics. You will master them and you will *like* it!"},
	{PIKER, "Do I have to?"},
  	},},
		
--by Linenpixel--
{
agents = {PRISM, GHUFF},
dialogue = {
{PRISM, "So, you have any dirt on anyone I used to work with?"},
{GHUFF, "Are you willing to pay me?"},
{PRISM, "Nah. Anything I haven't already heard is probably pretty boring anyway."},
{GHUFF, "Tell me about it. People go to such lengths to try to hide the same old shit."},
},
},	

--by Linenpixel--
{
agents = {MIST, PRISM},
dialogue = {
{MIST, "Given how experimental a lot of holovid tech still is, you really were a lab rat just like me."},
{PRISM, "Oh really? How much do lab rats get paid?"},
{MIST, "Um, nothing, but some of them become famous in academic journals."},
{PRISM, "I was famous in far more places than that. End of conversation."},
},
},
--by Linenpixel--
{
agents = {MIST, NIKA},
dialogue = {
{NIKA, "Can you destroy people with your mind?"},
{MIST, "That's not exactly what I do. I have made people pass out but it's not predictable enough to-"},
{NIKA, "Then you will need to use weapons."},
{MIST, "...Right."},
},
},

	
 -- --by Hekateras--
 -- {
  -- agents = {NAME, NAME},
  -- dialogue = {
	
	-- },},},	
  
}

return banter