---------------------------------------------------------------------
-- Invisible Inc. MOD.
--

local DLC_STRINGS =
{	           
	
	OPTIONS =
	{
		BANTER = "Additional banter",
		BANTER_TIP = "<c:FF8411>Adds mission start banters for multiple basegame, DLC and mod agents</c>",  
		
		BANTER_FREQ = "Banter frequency",
		BANTER_FREQ_DESC = "<c:FF8411>AGENT BANTER</c>\nHow often your agents talk with each other at the mission start.\nOverrides Generation Options+ mod settings.",
		BANTER_FREQ_STRINGS = {"NEVER = 0", "RARELY = 0.1", "NORMAL = 0.2", "OFTEN = 0.4", "VERY OFTEN = 0.7" ,"ALWAYS = 1.0"},
		
		SAA_MERGE = "Separate archived agent banters",
		SAA_MERGE_DESC = "Enable for the banter system to read archived versions of agents as separate people. Only possible with Separable Archived Agents mod. \nWARNING: Currently, this will stop archived versions from bantering with literally anyone except their own clone. \nThis entire option exists only so Sharp can embrace his narcissism, please don't take it seriously.",
	},	

	VANILLA_FIXES = {
		SHALEM = "A vat of nutri-paste and a fine steak are both food, but they’re not the same thing.",
		XU = "Can I borrow it? I promise to reassemble it afterwards.",
		MIDMISSION1_NAME = "Research Facility",
		ALARM_NEXT_INCREASEDFIREWALLS2 = "\n\n<c:F4FF78>NEXT SECURITY MEASURE:</>\nMAINFRAME firewalls will be HEAVILY strengthened.",
	},
	
	LOGS = 
	{	
	-- 	SHOPCAT datalog --
	log_shopcatp1_filename = "NETCRAWLER OUTPUT",
	log_shopcatp1_title = "Messageboard Recovery Log",
	log_shopcatp1 = [[Thread: NODE53434:/ur1stop_soft_shop / chatzone / offtopic / Let's talk about her - [page 34/36]
	Date retrieved: <c:62B3B3>10.21.2068 | [thread status: locked]</>
	User: <c:62B3B3>M@nB3h1ndTh3Curt@in</>
	Post title: <c:62B3B3>What if...</> | Post ID <c:62B3B3>[Share this post]: #40482</>
	
		<c:62B3B3>Shopcat was a normal cat once, roaming the abandoned canals of New York City. Lounging quietly by day and Hunting by night, she gave little thought to the comings and goings of the twolegs. Life was simple, and life was good.
	
		But one night, she found a delicious smell coming from a drainpipe. Normally she wouldn't have risked the trouble, but the Hunt had been bad of late. It was rainy season and the rats had gone to ground. She was hungry, and hungry cats make bad decisions. Just two careful steps into the pipe and a hard metal grate dropped down and trapped her inside. Soon after, the Doctor came.
	
		She doesn't remember much from the beginning of her time with the Doctor, and she doesn't care to. Bright lights. Loud noises. The smell of burning hair. But most of all, pain.
	
		There wasn't a particular moment that marked her transition from cat to something-more-than-cat. It came slowly, each strange new impulse or thought jumping into her head suddenly and then receding for a while. In time though, she came to realize what was happening to her - what the Doctor was trying to accomplish in his unlicensed laboratory hidden deep within the creaking hulk of an abandoned skyscraper in the middle of the Manhattan Flood Zone. She knew that she wasn't the first of his experiments, and that she wouldn't be the last. She came to realize what she had to do if she was going to survive.
	
		She bided her time. She endured the 'treatments', getting smarter and getting stronger with each, but always trying to hide the true extent of her transformation. If her plan was going to work, she would need to keep a part of herself secret. She would have to maintain the element of surprise.
		
		Afterwards - after the fire, the blood, and the darkness, as she dug her way out of the rubble of what was once a laboratory, she asked herself: 'What now? Were do I go from here?"
	
		She knew that she wouldn't last long back in the canals. She still loved the Hunt, but she knew that it wasn't enough. The foreign chemicals sloshing around in her head and the bright flashing machinery that bent her thoughts into man-shapes wouldn't run on the carcasses of rats and birds. They would slow down and eventually grind to a halt, and as they did, they would kill her. She was more-than-cat now, and she had more-than-cat needs.

		A tiny corp drone flitted overhead as night began to fall. She had seen them all over the Zone for her entire life, but had never until now given them a second thought. It must have a base station somewhere close by, with a power source and replacement parts, and most importantly, a data uplink. The thought bender knew what to do with that. It whispered instructions to her inside of her head, and then she knew too.

		The next time a drone flew past, she took off in pursuit. It felt good to be back to the Hunt after so long inside.</>
	
	Reactions: n/a]],


-- OLIVIA datalog --
log_olivia_filename = "CVR TRANSCRIPT",
log_olivia_title = "COCKPIT VOICE RECORDER TRANSCRIPT",
log_olivia = [[CVR Partial Transcript of Atatürk-Tangerine-Delta-5 (ATD5)

	<c:62B3B3>The privately-owned small aircraft was hijacked en route to Ankara on July 8, 2057 at 22:25 (19:25 UTC) by four assailants, after which all contact with the aircraft, including tracking data, was lost. Whereabouts of original crew and passenger currently unknown. The hijacking incident lasted ca. 50 minutes before the aircraft was picked up by local scanners in the vicinity of [REDACTED], XX km from where the hijacking occurred. Black box recovered at 05:10 local time on July 9. Transcript follows.</>

	- Key -

	<c:48D85F>M-HJ:</> <c:62B3B3> Male hijacker</>
	<c:EB9B0F>F-HJ:</> <c:62B3B3> Female hijacker</>
	
	- Transcript -

<c:EB9B0F>F-HJ:</> <c:62B3B3>Drag her to fire escape. We can (*incomprehensible*) Omicron is sweeping the exit. (pause) Objection noted. Now do as you're told.</>

<c:EB9B0F>F-HJ:</> <c:62B3B3>They've picked up the jet. We're out of time.

(Heavy static for approx. 2 seconds)</>

<c:48D85F>M-HJ:</> <c:62B3B3>What did you do?!</>

<c:EB9B0F>F-HJ:</> <c:62B3B3>What I had to. We'll talk about this later. I need you to find us a secure (*interrupted*)</>

<c:48D85F>M-HJ:</> <c:62B3B3>We could have extracted them, I could have grabbed one of them, at least! You had NO RIGHT(*interrupted*)</>

<c:EB9B0F>F-HJ:</> <c:62B3B3>You were barely in range, a second longer and you would have been stranded there, too. I'll need your skills if (*incomprehensible*) recover from this.</>

<c:48D85F>M-HJ:</> <c:62B3B3>Recover from this? Are you out of your mind? That was our chance, back there! We lost! That was it, do you, do you even realize that?</>

<c:EB9B0F>F-HJ:</> <c:62B3B3>We don't have time for this. Take control of the jet, there is something I need to do. (pause) That is an order, agent.</>

<c:48D85F>M-HJ:</> <c:62B3B3>(pause) Taking over manual control. (pause) I'll put out some feelers. Safe house is burned, we need to improvise. If there is still a "we". (pause) Care to explain what you're doing?</>

<c:EB9B0F>F-HJ:</> <c:62B3B3>Something I salvaged back in Luxembourg. She... it may be able to help us.</>

<c:48D85F>M-HJ:</> <c:62B3B3>A hard drive? What the blazes did you (*interrupted*)</>

<c:EB9B0F>F-HJ:</> <c:62B3B3>Hold it. Do you see that?</>

<c:48D85F>M-HJ:</> <c:62B3B3>Incoming, we've got incoming! Take cov(*incomprehensible*)</>

- End of transcript -
]],




-- MIST datalog --
log_mist_filename = "CORPORATE INTELLIGENCE",
log_mist_title = "PLASTECH R&D ASSESSMENT RECORD",
log_mist = [[Don't even ask how many hands this went through before I acquired it <c:a1ddb4>-Monst3r</>

---------------------------

EXECUTIVE ASSESSMENT RECORD
Original datestamp: Feb 22, 2062

<c:ffb54c>VP Research:</> <c:62B3B3>So, this is the experiment?</>

<c:fffeb2>Technician:</> <c:62B3B3>Yes. Mr. Souza, may I present Minna Kirstvinsdottir? Minna, this is our Vice-President of Research, Mr. Eduardo Souza.</>

<c:ffb54c>VP Research:</> <c:62B3B3>Oh. An actual name.</>

<c:b2fffe>Minna:</> <c:62B3B3>It's Icelandic. I was kidnapped from Iceland during the Resource Wars.</>

<c:ffb54c>VP Research:</> <c:62B3B3>You let her keep those memories?</>

<c:b2fffe>Minna:</> <c:62B3B3>I don't remember it. It's just what they've told me. They overwrote large parts of my brain. But I've been re-teaching myself Icelandic.</>

<c:ffb54c>VP Research:</> <c:62B3B3>Why do you allow this? This isn't part of the project goals.</>

<c:fffeb2>Technician:</> <c:62B3B3>Um, well, we've been following the informal best practices guide, and for underage subjects that does include personal time.</>

<c:b2fffe>Minna:</> <c:62B3B3>Marglytturnar eru logn.</>

<c:ffb54c>VP Research:</> <c:62B3B3>Like everyone who matters, I have a translator implant, and you just said "The jellyfish are calm."</>

<c:b2fffe>Minna:</> <c:62B3B3>Yes, but in Icelandic.</>

<c:ffb54c>VP Research:</> <c:62B3B3>Could we get down to business?</>

<c:fffeb2>Technician:</> <c:62B3B3>Yes, absolutely. I'll just connect this here... now, Mr. Souza, I must warn you-</>

<c:ffb54c>VP Research:</> <c:62B3B3>I've been briefed. I came here for a demonstration, and so far you've done nothing but waste my time.</>

<c:fffeb2>Technician:</> <c:62B3B3>Very well. Minna, if you're ready...</>

(3.5 seconds of silence, 0.5 second scream, indistinct thud)

<c:fffeb2>Technician:</> <c:62B3B3>Code blue! Code blue! Executive requiring medical attention!</>

<c:ffb54c>VP Research:</> <c:62B3B3>Ugh... what? Shut up! I'm fine!</>

<c:fffeb2>Technician:</> <c:62B3B3>Cancel code blue.</>

<c:b2fffe>Minna:</> <c:62B3B3>I'm sorry. His mind wasn't exactly like the ones I trained on.</>

<c:fffeb2>Technician:</> <c:62B3B3>It's okay, Minna.</>

<c:ffb54c>VP Research:</> <c:62B3B3>I'm fine! Bring me a stim! (huff) ...Yes, yes, I can definitely envision the applications...</>

---------------------------
]],



-- N-UMI datalog --
log_n_umi_filename = "UNBROADCAST FTM FOOTAGE",
log_n_umi_title = "SCRAPPED 2067 \"DAILY QUESTION\" FOOTAGE",
log_n_umi = [[ Incident Report #2298K7: TRANSCRIPT

<c:f787f5>FTM News Announcer:</> <c:62B3B3>It's not often we get to see the inside of a Sankaku research facility, but today, in what may be a sign of improved intercorporate relations, we've been invited to do just that. Bob Espinoza is coming to us live from Kyoto.</>

<c:f787f5>Interviewer:</> <c:62B3B3>Thank you, Peggy. It is so exciting to be here.</>

(Camera pans across a large, glassy room filled with tables, screens, equipment, drones and scientists. Camera cuts to a twenty-something Japanese woman.)

<c:f787f5>Interviewer:</> <c:62B3B3>I'm speaking to Umiko Nakagawa-</>

<c:4cbcff>Umiko:</> <c:62B3B3>Please, call me Umiko.</>

<c:f787f5>Interviewer:</> <c:62B3B3>Umiko. This cute little drone here caught my eye from across the room.</>

<c:4cbcff>Umiko:</> <c:62B3B3>Thank you. But it is just a side project, a hobby, if you will. It is a self-operating AI that-</>

<c:f787f5>Interviewer:</> <c:62B3B3>You programmed an AI just as a hobby?</>

<c:4cbcff>Umiko:</> <c:62B3B3>Not exactly. I trained it using a machine learning framework built by my colleagues. And it is only an ANI, or Artificial Narrow Intelligence, unlike Artificial General Intelligence, which-</>

<c:f787f5>Interviewer:</> <c:62B3B3>Whoa, slow down there.</>

<c:4cbcff>Umiko:</> <c:62B3B3>This is... a machine that is very good at doing one thing. But it has no idea how to do other things.</>

<c:f787f5>Interviewer:</> <c:62B3B3>(chuckle) So we don't have to worry about it taking over the world?</>

<c:4cbcff>Umiko:</> <c:62B3B3>You do not have to worry about it taking over the world because I didn't train it to take over the world. I trained it to navigate rooms.</>

<c:f787f5>Interviewer:</> <c:62B3B3>But could it learn how to do something different?</>

<c:4cbcff>Umiko:</> <c:62B3B3>Well, let me put it like this. Do you have a smart toaster?</>

<c:f787f5>Interviewer:</> <c:62B3B3>Doesn't everyone?</>

<c:4cbcff>Umiko:</> <c:62B3B3>So, how would you define "take over the world" in a way that your toaster would understand?</>

<c:f787f5>Interviewer:</> <c:62B3B3>Wow, that certainly is something to think about.</>

<c:4cbcff>Umiko:</> <c:62B3B3>It's not even that simple to define what it means to humans. And if you had 10 billion networked toasters, they would just want to make toast. So-</>

(loud buzzing, ending in high-pitched electronic noise)

<c:f787f5>Interviewer:</> <c:62B3B3>Whoa, looks like we had some interference- are you all right?</>

(Umiko is rubbing her forehead. She stops and smiles.)

<c:4cbcff>Umiko:</> <c:62B3B3>Some people's idea of a fun side project is to work on jamming devices. And sometimes that interacts badly with certain implants. I am fine now.</>

<c:f787f5>Interviewer:</> <c:62B3B3>Oh. Well, speaking of those other interesting projects-</>

(Another electronic noise, then the sound of breaking glass. Camera turns to the far end of the room, where a cloud of what appears to be red smoke is spreading. Camera abruptly points at the floor.)

<c:f787f5>Interviewer:</> <c:62B3B3>Is there any chance this is also one of your colleagues' projects?</>

(Umiko doesn't answer. Camera still pointed at the floor. Sounds of running, screams.)

<c:f787f5>Interviewer:</> <c:62B3B3>Peggy, do we have- wait, Umiko, don't you want to take your drone?</>

<c:4cbcff>Umiko:</> <c:62B3B3>No. I can make more.</>
]],

-- 	GOOSE datalog --
	log_goose_filename = "POLNET DISPATCH",
	log_goose_title = "INTERPOL EMAIL INTERCEPT",
	log_goose = [[From: XXXXX@interpol.int
Sent: October 25, 2072 19:10
To: XXXX@interpol.int
Subject: RE: RE: RE: RE: Polnet BOLO

<c:62B3B3>Alright, new guy. Listen very carefully.

This is not a joke.
This is not a prank.
This is not some stupid April Fool's thing half a year early.

I am not exaggerating when I say that if we didn't have to go through this shit with every. single. new guy who gets swapped in or transferred to the task force, we probably would have caught the damn thing by now.

I've tried memos. I've tried posters. I've tried PSAs. I've tried adding "No, the goose is not a joke" to my email signature. It never works.

Every couple of weeks we just straight-up lose paperwork because some new rookie or intern or trainee or whathaveyou up in the red tape department thinks the whole thing is a mistake and just chucks it in the dustbin and someone - usually me, and soon it's gonna be you - has to walk up there and set things straight again. Has to explain to the relevant people that yes, really, we are looking for a goose. It's the year 2072. We have spy cams on cybernetic roaches and smart Furbys that turn the lights on for you when you get home. The Most Wanted in the cybercrimes division is rumored to be an actual goddamn cat. But no, someone's freak science experiment running amok and shitting everywhere is apparently too much for people to handle.

Read the file.

And get to work.</>

--------------------------------------------------------

From: XXXX@interpol.int
Sent: October 25, 2072 18:43
To: XXXXX@interpol.int
Subject: RE: RE: RE:  Polnet BOLO

<c:62B3B3>Of course I opened it. You sent me a goose file. That's a goose.

Like I said, either you guys decided to prank the new guy - ha ha - or it's one of those secret personality assessments. Well, let me tell you, my common sense is intact. Not falling for that.</>

--------------------------------------------------------

From: XXXXX@interpol.int
Sent: October 25, 2072 18:41
To: XXXX@interpol.int
Subject: RE: RE: Polnet BOLO

<c:62B3B3>This is the real file. Have you actually opened it?</>

--------------------------------------------------------
From: XXXX@interpol.int
Sent: October 25, 2072 18:35
To: XXXXX@interpol.int
Subject: RE: Polnet BOLO

<c:62B3B3>Right.

Yeah.

I know a hazing when I see one.

The real file. If you don't mind.</>

--------------------------------------------------------
From: XXXXX@interpol.int
Sent: October 25, 2072 18:25
To: XXXX@interpol.int
Subject: Polnet BOLO

<c:62B3B3>I've added you to the access list for the file. Make sure you've read the full casework before the brief on Tuesday, chief's gonna want to grill you on it.</>

<c:F47932>==========Preview==========</>
BOLO ALERT

File ID
<c:F47932>IP9840-F03331</>

Special warnings
<c:F47932>Body armor recommended</>

Criminal charges
<c:F47932>Larceny, vandalism, conspiracy to commit larceny and vandalism, harassment, illegal intrusion, fraud, driving without a license, motor vehicle theft, identity theft, jaywalking, embezzling</>

Terrorist group & organised crime affiliations
<c:F47932>Unknown</>

Description
<c:F47932>Suspect is an approximately 0.95m tall goose (</>Anser anser domesticus<c:F47932>) with color and build matching the domesticated Embden breed (white feathers, orange bill and feet) or a hybrid. While superficially indistuishable from other members of its species, this bird displays unprecedented intelligence and problem-solving ability combined with a thirst for wanton destruction. Forensic evidence ties it to multiple incidents across the Greater Trans-Tasman K&O Zone. Genetic data confirms that the culprit is, in fact, biologically a goose (as opposed to a cleverly-disguised drone or other early theories) and the same goose in all reported cases.</>

Special remarks
<c:F47932>While (mostly) non-violent offenders wouldn't normally be our jurisdiction, the high profile and heavy financial damages suffered by some of the targets make this one a priority. Suffice to say, the suits at K&O want this one resolved ASAP.</>

<c:F47932>[Continue reading]
============================</>]],

	log_pedler_filename = "SUBNET HIGHLIGHT",
	log_pedler_title = "SUBNET AMA HIGHLIGHT ",
	log_pedler = [[<c:ffe287>SUBNET AMA HIGHLIGHTS - UNDERGROUND FIGHT STAR AMA</>

	Retrieved from: <c:62B3B3>NODE35926:/AMA/comments/3VuF5Wz/
	im_an_underground_fight_star_ask_me_anything/?sort=confidence
	Date retrieved: <c:62B3B3>01.20.2072</> <c:bcbcbc>[node deactivated as of 05.12.2072]</>
	Date posted: <c:62B3B3>21.03.2071</>
	<c:62B3B3>Posted by u/MustardCutter9000</>

	<c:62B3B3>What has been your most serious injury?</>
	<c:e95c4b>*Rotator cuff. Very expensive to replace.*</>

	<c:62B3B3>Why are you writing between asterisks like that?</>
	<c:e95c4b>*I speak using a text-to-speech synthesizer, and to type I simply omit the to-speech step. You are receiving my thoughts directly from my "brain".*</>

	<c:62B3B3>But couldn't you tell the software to omit the asterisks?</>
	<c:e95c4b>*Yes, if I wanted to be unstylish.*</>

	<c:62B3B3>Is it dark underground? Or do they have special lights?</>
	<c:e95c4b>*I suspect you are joking, my friend.*</>

	<c:62B3B3>Lol, maybe</> <c:bcbcbc>[user deactivated]</> <c:62B3B3>is onto something. Those venues are huge. Literally underground might be the best place to hide them.</>
	<c:e95c4b>*That was not a question. And I will never betray the location of my fellow contenders.*</>

	<c:62B3B3>With an attitude like that, we could use you in the struggle to overthrow our corporate oppressors!</>
	<c:e95c4b>*Also not a question.*</>

	<c:bcbcbc>[question deleted]</>
	<c:e95c4b>*You need to be more specific. Is it a robo-duck? Do the horses share a gestalt consciousness? Was gene editing involved?*</>

	<c:62B3B3>You've dropped hints that you're at least partially cybernetic. What is your stance on cyborg and AI rights?</>
	<c:e95c4b>*My stance is a fighting one! Ha ha! And it is questions about fighting that I am here to answer!*</>

	<c:62B3B3>I believe that the bread-and-circuses effect of underground fighting rings is only enhanced by a carefully cultivated illusion of illicitness, much like with SubNet itself. Thoughts?</>
	<c:bcbcbc>[156 replies deleted]</>

	<c:62B3B3>Do you like soup?</>
	<c:e95c4b>*No.*</>]],

}, -- end of logs

	
}

return DLC_STRINGS